/* Corbin March
 * TuringMachine.java
 *
 * Created on November 3, 2002, 5:55 PM
 * The TuringMachine is the driving class for the collected Turing classes.
 * It stores transitions in a hash table. When an input string is presented,
 * it instantiates a TuringTape and tests the string against the Machine.
 */
import java.util.Hashtable;
import java.util.StringTokenizer;

public class TuringMachine {
    
    private Hashtable transitions;
    private String initialState;
    private String currentState;
    private String[] finalStates;
    
    /** Creates a new instance of TuringMachine */
    public TuringMachine() {
        transitions = new Hashtable();
    }
    
    /** initializes the initial machine state*/
    public void setInitialState(String s){
        initialState  = s;
    }
    
    /** initializes the machine's final states.*/
    public void setFinalStates(String s){
        StringTokenizer tokenizer = new StringTokenizer(s,",");
        finalStates = new String[tokenizer.countTokens()];
        for(int i = 0;i < finalStates.length;i++){
            finalStates[i] = tokenizer.nextToken();
        }
    }
    
    /** stores transition functions in a hashtable*/
    public void addTransition(String s){
        String hashKey = "";
        String hashValue = "";
        StringTokenizer tokenizer = new StringTokenizer(s,",");
        hashKey = hashKey + tokenizer.nextToken();
        hashKey = hashKey + tokenizer.nextToken();
        hashValue = hashValue + tokenizer.nextToken() + ",";
        hashValue = hashValue + tokenizer.nextToken() + ",";
        hashValue = hashValue + tokenizer.nextToken();
        transitions.put(hashKey,hashValue);
    }
    
    /**runScenario contains the important workings of the machine.
     * it accepts an input string, places it on the TuringTape
     * and then evalutes it. If no transition is defined for the current
     * character and state, it halts. If there is a transition, then a new
     * letter is written and the head moves.
     */
    public boolean runScenario(String s){
        String currentKey;
        boolean halt = false;
        currentState = initialState;
        TuringTape tapeAndHead = new TuringTape(s);
        System.out.println("Tape: " + tapeAndHead.printTape()); 
        System.out.println("State: " +currentState);    //initial state
        while(!halt){
            currentKey = currentState + tapeAndHead.readCell();
            if(transitions.containsKey(currentKey)){
                StringTokenizer tokenizer = new StringTokenizer((String)transitions.get(currentKey),",");
                currentState = tokenizer.nextToken();
                tapeAndHead.writeCell(tokenizer.nextToken().charAt(0));
                if(tokenizer.nextToken().equals("R")){
                    tapeAndHead.moveRight();
                }
                else{
                    tapeAndHead.moveLeft();
                }
                System.out.println("Tape: " + tapeAndHead.printTape());
                System.out.println("State: " +currentState);
            }
            else{   //no transition defined
                halt = true;
            }
        }
        return checkIfFinal();
    }
    
    /*checkIfFinal tests to see if the machine is in a final
     *state after it halts and therefore accepts the string as being in 
     *it's defined language.
     */
    private boolean checkIfFinal(){
        boolean answer = false;
        for(int i = 0;i < finalStates.length;i++){
            if(currentState.equals(finalStates[i])){
                answer = true;
            }
        }
        return answer;
    }
}
