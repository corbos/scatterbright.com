/* Corbin March
 * TuringTape.java
 *
 * Created on November 3, 2002, 2:59 PM
 * The TuringTape is a thinly veiled doubly-linked list that acts as the 
 * infinite data tape for the TuringMachine.
 * It also contains the logic for the read/write head that uses it.
 */
public class TuringTape {
    
    private TuringTapeCell readWriteHead;
    private TuringTapeCell leftBorder, rightBorder;
    
    /** Creates a new instance of TuringTape */
    public TuringTape(String startString){
        readWriteHead = new TuringTapeCell('|',null,null);
        leftBorder = readWriteHead;
        rightBorder = readWriteHead;
       
        for(int i = 0;i < startString.length();i++){
            char c;
            c = startString.charAt(i);
            rightBorder.setCellChar(c);
            addCellRight('#');
        }
    }
    
    /*adds a cell to the tape's leftmost edge*/
    private void addCellLeft(char c){
        TuringTapeCell newCell = new TuringTapeCell(c,null,leftBorder);
        leftBorder.setLeftCell(newCell);
        leftBorder = leftBorder.getLeftCell();
    }
    
    /*adds a cell to the tape's rightmost edge*/
    private void addCellRight(char c){
        TuringTapeCell newCell = new TuringTapeCell(c,rightBorder,null);
        rightBorder.setRightCell(newCell);
        rightBorder = rightBorder.getRightCell();
    }
    
    /*returns the contents of the tape as a string*/
    public String printTape(){
        String tapeContents;
        tapeContents = "";
        TuringTapeCell cursor = leftBorder;
        while(cursor != null){
            if(cursor == readWriteHead) //read/write head is above the cell.
                tapeContents = tapeContents + "^";
            tapeContents = tapeContents + cursor.getCellChar();
            cursor = cursor.getRightCell();
        }
        return tapeContents;
    }
    
    /*moves the read/write head to the left.
     *If there is no cell defined, an empty cell is added*/
    public void moveLeft(){
        if(readWriteHead.getLeftCell() == null){
            addCellLeft('#');   //there is no where to move, add an empty cell
        }
        readWriteHead = readWriteHead.getLeftCell();
    }
    
     /*moves the read/write head to the right.
     *If there is no cell defined, an empty cell is added*/
     public void moveRight(){
        if(readWriteHead.getRightCell() == null){
            addCellRight('#');  //there is no where to move, add an empty cell
        }
        readWriteHead = readWriteHead.getRightCell();
    }
     
     /*writes a character on the cell below the read/write head*/
     public void writeCell(char c){
         readWriteHead.setCellChar(c);
     }
     
     /*reads the character on the cell below the read/write head*/
     public char readCell(){
         return readWriteHead.getCellChar();
     }
}
