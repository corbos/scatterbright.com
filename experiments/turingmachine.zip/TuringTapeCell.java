/* Corbin March
 * TuringNode.java
 *
 * Created on November 3, 2002, 2:29 PM
 * A TuringTapeCell is a single cell on a TuringTape. It can be read from
 * and written to. It is linked to other cells to create the illusion of
 * and infinite tape.
 */
public class TuringTapeCell {
    
    private char cellChar;
    private TuringTapeCell linkLeft;
    private TuringTapeCell linkRight;
    
    /** Creates a new instance of TuringNode */
    public TuringTapeCell(char c,TuringTapeCell left,TuringTapeCell right) {
        cellChar = c;
        linkLeft = left;
        linkRight = right;
    }
    
    /*gets the char and the cell*/
    public char getCellChar(){
        return cellChar;
    }
    
    /*get the cell that the current cell is linked to on the left*/
    public TuringTapeCell getLeftCell(){
        return linkLeft;
    }
    
    /*sets the left link of the current cell*/
    public void setLeftCell(TuringTapeCell cell){
        linkLeft = cell;
    }
    
     /*get the cell that the current cell is linked to on the right*/
    public TuringTapeCell getRightCell(){
        return linkRight;
    }
    
     /*sets the right link of the current cell*/
    public void setRightCell(TuringTapeCell cell){
        linkRight = cell;
    }
    
    /*sets the cell's char*/
    public void setCellChar(char c){
        cellChar = c;
    }
}
