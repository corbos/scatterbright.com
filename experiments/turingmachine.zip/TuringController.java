/* Corbin March
 * TuringController.java
 *
 * Created on November 3, 2002, 7:37 PM
 * The TuringController is the crude commandline GUI for the TuringMachine.
 * It accepts a path to an algorithm data file, instantiates the TuringMachine
 * and loads it with the algorith,
 */
import java.io.*;

public class TuringController {
    
    /** Creates a new instance of TuringController */
    public TuringController() {
        String readString;
        TuringMachine machine = new TuringMachine();
        try{
            BufferedReader keyReader = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Specify your algorithm's data file:");
            readString = keyReader.readLine();  //get the data file.
            BufferedReader fileBuffer = new BufferedReader(new FileReader(readString));
            System.out.println("Reading from file: " + readString);
            //populate the machine.=================================
            readString = fileBuffer.readLine();
            machine.setFinalStates(readString);
            readString = fileBuffer.readLine();
            machine.setInitialState(readString);
            while((readString = fileBuffer.readLine()) != null){
                machine.addTransition(readString);
            }
            //Everything is loaded. Time for input strings.=================
            System.out.println("The machine is ready. Type strings to be tested: ");
            while((readString = keyReader.readLine()).equalsIgnoreCase("quit") == false){
                if(machine.runScenario(readString)){
                    System.out.println(readString + " IS in the language.");
                }
                else{
                    System.out.println(readString + " NOT in the language.");
                }
            }
            System.out.println("Ending...");    
        }
        catch(FileNotFoundException e){
            System.out.println(e.toString());
        }
        catch(IOException e){
            System.out.println(e.toString());
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new TuringController();
    }
    
}
